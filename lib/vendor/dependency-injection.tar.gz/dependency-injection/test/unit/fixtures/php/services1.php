<?php

class ProjectServiceContainer extends sfServiceContainer
{
  protected $shared = array();
}
