<?php

class Container extends AbstractContainer
{
  protected $shared = array();
}
